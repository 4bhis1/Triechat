from django.shortcuts import redirect, render
from .python_code import random_name as rn
from .python_code import encryption as ec
from app.models import Room,User,Message

from datetime import date
from datetime import datetime


today=date.today().strftime('%d %b %y')
time=datetime.now().strftime('%H : %M:%S')

# Create your views here.

def home(request):
    k=str(rn.random_name())
    
    t=User(user_name=k)
    t.save()
    
    st=ec.encrypt(k)
    print(k)
    room=ec.encrypt('common')
    
    return redirect(room+'/'+st)


def common(request,room,user):
    
    room=ec.decrypt(room)
    user=ec.decrypt(user)
    
    roomlist=Room.objects.all()
    userlist=User.objects.all()
    messagelist=Message.objects.filter(room=room).values()
    
    if request.method=="POST":
        
        if request.POST.get('User_name'):
            
            k=request.POST['User_name']
            
            u=User.objects.get(user_name=user)
            u.user_name=k
            
            u.save()
            
            room=ec.encrypt('common')
            st=ec.encrypt(k)
    
            return render(request,"main.html",{'room':room,'user':user,'roomlist':roomlist,'userlist':userlist,'message':messagelist})
        
        elif request.POST.get('Room_name'):
            
            rname=request.POST['Room_name']
            passw=request.POST['Password']
            
            r=Room(name=rname,password=passw,admin=user)
            r.save()
            
        else:
            print("hi")
            try:
                file=request.FILES["media"]
            except:
                file=''
            msg=request.POST["msg"]
            
            today=date.today().strftime("%Y-%m-%d")
            time=datetime.now().strftime('%H:%M:%S')
            
            t=Message(room=room,user=user,msg=msg,file=file,time=time,date=today)
            t.save()
            
            return render(request,"main.html",{'room':room,'user':user,'roomlist':roomlist,'userlist':userlist,'message':messagelist})
    
    
    return render(request,"main.html",{'room':room,'user':user,'roomlist':roomlist,'userlist':userlist,'message':messagelist})   


def room(request,room,user):
    
    
    
    return render(request,'room.html')